create view view_stu as
select `databasetest`.`students`.`math`                                         AS `math`,
       `databasetest`.`students`.`chinese`                                      AS `chinese`,
       (`databasetest`.`students`.`math` + `databasetest`.`students`.`chinese`) AS `math+chinese`
from `databasetest`.`students`;

