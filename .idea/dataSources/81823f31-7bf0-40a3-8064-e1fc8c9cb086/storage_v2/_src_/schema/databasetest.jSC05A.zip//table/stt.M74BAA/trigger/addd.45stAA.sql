create trigger addd
  after INSERT
  on stt
  for each row
begin
update class set stucount = stucount + '1';
end;

