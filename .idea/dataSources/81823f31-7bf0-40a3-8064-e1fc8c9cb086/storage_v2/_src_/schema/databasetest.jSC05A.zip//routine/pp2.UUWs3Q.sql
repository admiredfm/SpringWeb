create procedure pp2(IN in_i int)
begin
select in_i;
end;

