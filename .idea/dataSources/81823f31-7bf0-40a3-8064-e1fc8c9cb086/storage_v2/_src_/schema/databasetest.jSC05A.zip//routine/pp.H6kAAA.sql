create procedure pp()
begin
select * from sc;
end;

